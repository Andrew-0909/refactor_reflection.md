let canvasX = 400;
let canvasY = 500;


class Circle{
  constructor(x, y, diameter, xSpeed, ySpeed, color)
  {this.x = x
   this.y = y
   this.diameter = diameter
   this.xSpeed = xSpeed
   this.ySpeed = ySpeed
   this.color = color}
  
  display(){
    fill(this.color);
    circle(this.x,this.y, this.diameter);
  }
  
  
  move() {
  this.x += this.xSpeed
  this.y += this.ySpeed
  
if (this.x > canvasX - this.diameter/2 || this.x < this.diameter/2){
  this.xSpeed *= -1;
} 
    if (this.y > canvasY - this.diameter/2 || this.y < this.diameter/2) {
     this.ySpeed *= -1; 
    } 
  }
}

class Rect{
  constructor(x, y, w, h, xSpeed, ySpeed, color)
  {this.x = x
   this.y = y
   this.w = w
   this.h = h
   this.xSpeed =xSpeed
   this.ySpeed = ySpeed
   this.color = color}
  
  display(){
    fill(this.color);
    rect(this.x,this.y, this.w, this.h);
  }
  
  move() {
  this.x += this.xSpeed
  this.y += this.ySpeed
 
  if (this.x > canvasX - this.w || this.x < 0) {
    this.xSpeed *= -1;
  }
  if (this.y > canvasY - this.h || this.y < 0) {
    this.ySpeed *= -1;
  }
  }
}

function overlap (circle, rect) {
    
  // 이 밑에 두줄은 rectangle 과 circle 사이의 x 와 y 거리를 구합니다
  let distX = Math.abs(circle.x - rect.x - rect.w / 2);
  let distY = Math.abs(circle.y - rect.y - rect.h / 2);
         
  // 거리가 겹칠정도로 가까워지면 false (거짓) 결과를 내보냄 
  // overlap 가 거짓이다.
  if (distX > (rect.w / 2 + circle.diameter / 2)) return false;
  if (distY > (rect.h / 2 + circle.diameter / 2)) return false;
  
  if (distX <= (rect.w / 2)) return true;
  if (distY <= (rect.h / 2)) return true;
  
  let dx = distX - rect.w / 2;
  let dy = distY - rect.h / 2;
  return (dx * dx + dy * dy <= circle.diameter/2 * circle.diameter/2);
  
}

let newCircle
let newRectangle

function setup() {
  createCanvas(canvasX, canvasY);
  newCircle = new Circle (200, 200, 100, 5, 5, [30,30,200]);
  newRectangle = new Rect (50, 50, 100, 100, -3, -3, [200, 30, 30]);
}

function draw() {
  background(220);
  newCircle.display();
  newCircle.move();
  newRectangle.display();
  newRectangle.move();
  
  if (overlap(newCircle, newRectangle)) {
    console.log ("Overlap!");
  }
  
}
